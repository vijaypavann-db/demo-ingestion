import logging
import uuid

from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import *

from com.db.fw.etl.core.pipeline.PipelineBuilder import *
from com.db.fw.etl.core.common.DeltaStatLogger import IOService
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS

class PipelineUtils:

    metadata_db = COMMON_CONSTANTS.METADATA_DB
    entity_tbl = COMMON_CONSTANTS.PIPELINE_METADATA_TABLE
    entity_runs_tbl = COMMON_CONSTANTS.PIPELINE_OPTIONS_TABLE

    def __init__(self):
        self.spark = SparkSession.builder.getOrCreate()
    
    def buildPipelineUsingRunId(self, run_id: str):
        operations = (self.spark.read.table(f"{self.metadata_db}.{self.entity_runs_tbl}")
                        .filter(f"run_id == '{run_id}'") )
        
        entities = self.spark.read.table(f"{self.metadata_db}.{self.entity_tbl}")
        
        pipeline_details = entities.join(operations, entities["id"] == operations["entity_id"], "inner").head()
        
        return self.pipelineBuilder(pipeline_details)

    def pipelineBuilder(self, pipeline_details: Row): 

        # Pipeline Info       
        pipeline_id = pipeline_details["entity_id"]
        run_id = pipeline_details["run_id"]

        # Entity Info
        database = pipeline_details["db_name"]
        entity_name = pipeline_details["name"]
        entity_details = pipeline_details["details"]
        file_format = entity_details["format"]
        delimiter = entity_details.get("delimiter", ",")
        partition_keys = entity_details.get("partition_cols", "").lower()

        # Run Info
        run_details = pipeline_details["run_details"]
        input_path = run_details.get("path", "")
        write_mode = run_details.get("mode", "append")

        # TODO add Loggers for Options

        # Reader Configs
        reader_configs = {"file_format": file_format, "input_path": input_path}

        # Reader Options
        reader_options = None
        if file_format == "csv":
            csv_options = {"delimiter": delimiter}
            if entity_details.get("header") == "true":
                csv_options = csv_options | {"header": "true"}
            else:
                # TODO read schema from headerPath / headerCols & add the datatype info
                csv_options = csv_options | { "schema": "true"}
            reader_options = csv_options

        elif file_format == "json":        
            # TODO specify json options here
            json_options = {}
            reader_options = json_options
        elif file_format == "snowflake":
            reader_options = entity_details | run_details

        print(f"reader_configs {reader_configs} \n reader_options {reader_options}")
        
        # Processor Options
        processor_options = entity_details
        print(f"processor_options {processor_options}")

        # Writer Options
        writer_configs = {"mode": write_mode, "database": database, "entity_name": entity_name}
        
        # Writer Options
        writer_options = None
        if partition_keys:
            # TODO add other writer options
            writer_options = {"partition_keys": partition_keys}

        print(f"writer_configs {writer_configs} \n writer_options {writer_options}")

        file_sources = ["csv", "json", "text", "parquet", "avro", "orc"]

        task = PipelineNodeBuilder.SAMPLE_DF_READER
        if file_format.lower() in file_sources:
            task = PipelineNodeBuilder.GENERIC_BATCH_READER
            
        # If file_source & reader_options present pass the reader_option to reader
        reader = (PipelineNodeBuilder() 
            .set_name(f"{file_format}_df_reader_{run_id}") 
            .set_type(task) 
            .add_input_option("configs", reader_configs)
            .add_input_option("options", reader_options)
            .build() )

        writer = (PipelineNodeBuilder() 
            .set_name(f"delta_writer_{run_id}") 
            .set_type(PipelineNodeBuilder.DELTA_WRITER) 
            .add_input_option("mode", write_mode) 
            .add_input_option(COMMON_CONSTANTS.DB_NAME, database) 
            .add_input_option(COMMON_CONSTANTS.TABLE_NAME, entity_name) 
            .add_input_option(COMMON_CONSTANTS.OPTIONS, writer_options)
            .add_input_option(COMMON_CONSTANTS.CONFIGS, writer_configs)
            .build() )

        io_service = IOService()
        logger = logging.getLogger(__name__)

        pipeline = (PipelineBuilder(self.spark, entity_name, logger, pipeline_id, io_service) 
            .add_node(reader) 
            # .add_node_after(reader.name, processor) \
            .add_node_after(reader.name, writer).build() )

        pip_id,name,meta_jsons = PipelineBuilder.get_json_dump(pipeline)
        print(pip_id)
        print(name)
        print(meta_jsons)

        return pipeline
