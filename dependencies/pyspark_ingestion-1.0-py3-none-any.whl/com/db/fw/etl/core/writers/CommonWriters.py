from com.db.fw.etl.core.exception.EtlExceptions import *
from com.db.fw.etl.core.common.Task import Task
from com.db.fw.etl.core.writers.CommonWritingUtils import *


class BaseWriter(Task):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)


class DeltaWriter(BaseWriter):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):

        mode = self.input_options.get("mode", None)

        inputDf = self.get_input_dataframe()

        if mode == "append":
            delta_insert(self.spark, inputDf, self.input_options, COMMON_CONSTANTS.APPEND)
        elif mode == "overwrite":
            delta_insert(self.spark, inputDf, self.input_options, COMMON_CONSTANTS.OVERWRITE)
        elif mode == "delete":
            delta_delete(self.spark, options=self.input_options)
        elif mode == "update":
            delta_update(self.spark, inputDf, self.input_options)
        elif mode == "merge":
            delta_merge(self.spark, inputDf, self.input_options)
        else:
            raise InsufficientParamsException(
                self.task_name, self.pipeline_name, str(self.input_options))


class ConsoleWriter(BaseWriter):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        final_df = self.get_input_dataframe()
        if final_df is None or final_df.isStreaming:
            pass
        else:
            final_df.show(10, truncate=False)

            # .writeStream.format("console")\
            # .outputMode("append").start()
