from datetime import datetime


class Commons:

    DEBUG_PRINT_ON = False
    ERROR_PRINT_ON = False

    @staticmethod
    def get_current_time():
        x = datetime.now()
        curr_time = x.strftime("%Y-%m-%d %H:%M:%S.%f")
        return curr_time

    @staticmethod
    def printInfoMessage(message):
        if Commons.DEBUG_PRINT_ON:
            print(message)

    @staticmethod
    def printErrorMessage(message):
        if Commons.ERROR_PRINT_ON:
            print(message)
