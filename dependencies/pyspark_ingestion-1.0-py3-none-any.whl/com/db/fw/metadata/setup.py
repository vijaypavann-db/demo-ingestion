from com.db.fw.etl.core.exception.EtlExceptions import InsufficientParamsException
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip
from com.db.fw.metadata.queries import TableDDLS

class MetadataSetup:

    def __init__(self, db_name = "demo_metadata", dropTables = False, debug = False) -> None:
        
        builder = (SparkSession.builder.master("local[*]").appName("Local Metadata Setup")
                   .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
                   .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog"))

        self.spark = configure_spark_with_delta_pip(builder).getOrCreate()

        self.db = db_name
        self.debug = debug
        self.dropTables = dropTables
        self.queries = TableDDLS.get_queries()
        
        if debug:
            print(f"SparkSession initialized with name: `{self.spark.sparkContext.appName}`")
            print(f"Parameters: {self.__dict__} ")

    def createDB(self):
        query = f"CREATE DATABASE IF NOT EXISTS {self.db};"
        if self.debug:
            print(query)

        self.spark.sql(query)

    def createTable(self, table_name = None) -> str:
        task_name = "Local"
        pipeline_name = "Metadata Setup"
            

        if table_name is None:
            message = f"Table Name is missing!!!"            
            raise InsufficientParamsException(task_name = task_name, pipeline_name = pipeline_name, message = message, input_options = None)

        drop_query = f"DROP TABLE IF EXISTS {self.db}.{table_name};"
        
        create_query = self.queries.get(f"{table_name}_create_query", None)

        if create_query is None:
            message = f"DDL / Schema is not found for `{table_name}` key: {table_name}_create_query !!!"
            raise InsufficientParamsException(task_name = task_name, pipeline_name = pipeline_name, message = message, input_options = None)

        if self.debug:
            print(f"drop_query: {drop_query}, \n create_query: {create_query}")
            
        if self.dropTables:    
            self.spark.sql(drop_query)
            print(f"**** Table dropped {table_name}")

        self.spark.sql(f"USE {self.db};")

        print(f"currentDatabase :: {self.spark.catalog.currentDatabase()}")

        try:
            self.spark.sql(create_query)
            return f"**** Table created `{table_name}` \n"
        except Exception as ex:
            print(ex)
            return str(False)

    def run(self):
        self.createDB()
        tables = ["pipeline_status", "task_status", "operational_stats", "pipeline_metadata", "entity", "entity_runs"]
        [print(self.createTable(table)) for table in tables]
        # self.createTable(table_name = "pipeline_status") 