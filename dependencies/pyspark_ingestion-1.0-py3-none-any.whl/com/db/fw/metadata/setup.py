from com.db.fw.etl.core.exception.EtlExceptions import InsufficientParamsException
from pyspark.sql import SparkSession
from com.db.fw.metadata.queries import TableDDLS
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS

class MetadataSetup:
    """
    Utility Class to setup the Pipeline Metadata Database and Tables. Uses queries which contains all the Table DDLS.

    Code examples:
    1. It uses the `cx_poc` database to store the Metadata Tables, drops the existing tables and logs all the SQL queries
        setup = MetadataSetup(db_name = "cx_poc", debug = True, dropTables = True)
        setup.run()

    2. It uses the `cx_poc` database to store the Metadata Table `custom_tbl`, doesn't drop the existing tables [default] and doesn't log the SQL queries [default]
        setup = MetadataSetup(db_name = "cx_poc")
        setup.createTable("custom_tbl")

    :param spark: SparkSession object to run the SQL queries.
    :param db_name: Database to use for storing the metadata tables [default = "demo_metadata"].
    :param dropTables: Flag to drop the existing metadata tables [default = False].
    :param debug: Flag to enable debugging. Prints all the SQL queries being executed [default = False].

    .. versionadded:: 1.0

    .. note:: Evolving
    """
    def __init__(self, spark: SparkSession, db_name = COMMON_CONSTANTS.DB_NAME, dropTables = False, debug = False) -> None:

        self.spark = spark
        self.db = db_name
        self.debug = debug
        self.dropTables = dropTables
        self.queries = TableDDLS.get_queries()
        
        if debug:
            print(f"SparkSession initialized with name: `{self.spark.sparkContext.appName}`")
            print(f"Parameters: {self.__dict__} ")

    def createDB(self):
        query = f"CREATE DATABASE IF NOT EXISTS {self.db};"
        if self.debug:
            print(query)

        self.spark.sql(query)

    def createTable(self, table_name = None) -> str:
        task_name = "Setup"
        pipeline_name = "Metadata"
            

        if table_name is None:
            message = f"Table Name is missing!!!"            
            raise InsufficientParamsException(task_name = task_name, pipeline_name = pipeline_name, message = message, input_options = None)

        drop_query = f"DROP TABLE IF EXISTS {self.db}.{table_name};"
        
        create_query = self.queries.get(f"{table_name}_create_query", None)

        if create_query is None:
            message = f"DDL / Schema is not found for `{table_name}` key: {table_name}_create_query !!!"
            raise InsufficientParamsException(task_name = task_name, pipeline_name = pipeline_name, message = message, input_options = None)

        if self.debug:
            print(f"drop_query: {drop_query}, \n create_query: {create_query}")
            
        if self.dropTables:    
            self.spark.sql(drop_query)
            print(f"**** Table dropped {table_name}")

        self.spark.sql(f"USE {self.db};")

        print(f"currentDatabase :: {self.spark.catalog.currentDatabase()}")

        try:
            self.spark.sql(create_query)
            return f"**** Table created `{table_name}` \n"
        except Exception as ex:
            print(ex)
            return str(False)

    def run(self):
        self.createDB()
        tables = ["pipeline_metadata", "pipeline_options", "pipeline_status", "task_status", "operational_stats"]
        [print(self.createTable(table)) for table in tables]
        # self.createTable(table_name = "pipeline_status") 