
class TableDDLS:

    @staticmethod
    def get_queries() -> dict:
        return {"task_status_create_query" : f"""CREATE TABLE task_status
                                                            (
                                                                task_id STRING,
                                                                pipeline_name STRING,
                                                                pipeline_id STRING,
                                                                task_name STRING,
                                                                task_status STRING,
                                                                updated_at TIMESTAMP,
                                                                error_msg STRING
                                                            )
                                                            USING DELTA; """ ,
                         "pipeline_status_create_query" : f"""CREATE TABLE pipeline_status
                                                                        (
                                                                            id STRING,
                                                                            pipeline_name STRING,
                                                                            pipeline_id STRING,
                                                                            status STRING,
                                                                            updated_at TIMESTAMP,
                                                                            error_msg STRING
                                                                        )
                                                                        USING DELTA; """ ,
                        "operational_stats_create_query" : """CREATE TABLE operational_stats
                                                                            (
                                                                                pipeline_id STRING,
                                                                                pipeline_name STRING,
                                                                                task_name STRING,
                                                                                stat_name STRING,
                                                                                stat_value STRING,
                                                                                updated_at TIMESTAMP,
                                                                                batch_id STRING
                                                                            )
                                                                            USING DELTA; """ ,
                        "pipeline_metadata_create_query" : """CREATE TABLE pipeline_metadata
                                                                            (
                                                                            pipeline_id STRING,
                                                                            pipeline_name STRING,
                                                                            node_info STRING
                                                                            )
                                                                            USING DELTA; """ ,
                        "entity_create_query" : """CREATE TABLE Entity
                                                                (
                                                                    id STRING,
                                                                    db_name STRING,
                                                                    name STRING,
                                                                    entity_type STRING,
                                                                    insert_time TIMESTAMP,
                                                                    latest_status STRING,
                                                                    update_date STRING,
                                                                    updated_at TIMESTAMP,
                                                                    details MAP<STRING, STRING>
                                                                )
                                                                USING DELTA; """ ,
                        "entity_runs_create_query" : """CREATE TABLE Entity_Runs
                                                                    (
                                                                        run_id STRING,
                                                                        entity_id STRING,
                                                                        start_time TIMESTAMP,
                                                                        end_time TIMESTAMP,
                                                                        run_status STRING,
                                                                        exception_details STRING,
                                                                        updated_at timestamp,
                                                                        run_details MAP<STRING, STRING>
                                                                    )
                                                                    USING DELTA; """                                                                                                                                                                                                                                              
                }