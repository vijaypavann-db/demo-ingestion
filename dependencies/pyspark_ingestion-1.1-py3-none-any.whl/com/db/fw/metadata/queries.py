
class TableDDLS:

    @staticmethod
    def get_queries() -> dict:
        return {"pipeline_metadata_create_query" : """CREATE TABLE pipeline_metadata
                                                                            (
                                                                                pipeline_id STRING,
                                                                                pipeline_name STRING,
                                                                                db_name STRING,
                                                                                entity_name STRING,
                                                                                pipeline_type STRING,
                                                                                insert_time TIMESTAMP,
                                                                                updated_at TIMESTAMP,
                                                                                updated_on DATE GENERATED ALWAYS AS (CAST(insert_time AS DATE))    
                                                                            )
                                                                            USING DELTA; """ ,
                "pipeline_options_create_query" : """CREATE TABLE pipeline_options
                                                                    (
                                                                        run_id STRING,
                                                                        pipeline_id STRING,
                                                                        reader_configs MAP<STRING, STRING>,
                                                                        reader_options MAP<STRING, STRING>,
                                                                        processor_configs MAP<STRING, STRING>,
                                                                        processor_options MAP<STRING, STRING>,
                                                                        writer_configs MAP<STRING, STRING>,
                                                                        writer_options MAP<STRING, STRING>,
                                                                        node_info STRING,
                                                                        insert_time TIMESTAMP,
                                                                        updated_on DATE GENERATED ALWAYS AS (CAST(insert_time AS DATE)),
                                                                        is_active Boolean
                                                                    )
                                                                    USING DELTA; """ ,
                "pipeline_status_create_query" : f"""CREATE TABLE pipeline_status
                                                                        (
                                                                            run_id STRING,
                                                                            pipeline_id STRING,
                                                                            status STRING,
                                                                            updated_at TIMESTAMP ,
                                                                            updated_on DATE GENERATED ALWAYS AS (CAST(updated_at AS DATE)),
                                                                            error_msg STRING
                                                                        )
                                                                        USING DELTA; """ ,
                "task_status_create_query" : f"""CREATE TABLE task_status
                                                            (
                                                                task_id STRING,
                                                                task_name STRING,
                                                                run_id STRING,
                                                                pipeline_id STRING,
                                                                status STRING,
                                                                updated_at TIMESTAMP,
                                                                error_msg STRING
                                                            )
                                                            USING DELTA; """ ,
                "operational_stats_create_query" : """CREATE TABLE operational_stats
                                                                            (
                                                                                stat_id STRING,
                                                                                task_id STRING,
                                                                                run_id STRING,
                                                                                pipeline_id STRING,
                                                                                stat_name STRING,
                                                                                stat_value STRING,
                                                                                updated_at TIMESTAMP,
                                                                                batch_id STRING
                                                                            )
                                                                            USING DELTA; """ ,
                "pipeline_dependencies_create_query" : """CREATE TABLE pipeline_dependencies 
                                                                               (
                                                                                    parent STRING,
                                                                                    child STRING,
                                                                                    sequence BIGINT,
                                                                                    pipeline_id STRING,
                                                                                    pipeline_name STRING,
                                                                                    current_indicator INT,
                                                                                    effective_date DATE,
                                                                                    end_date DATE
                                                                                )
                                                                            USING DELTA; """ ,
                "pipeline_tasks_create_query" : """CREATE TABLE pipeline_tasks
                                                                            (
                                                                                task_id STRING,
                                                                                task_name STRING,
                                                                                pipeline_id STRING,
                                                                                pipeline_name STRING,
                                                                                task_configs MAP<STRING, STRING>,
                                                                                task_options MAP<STRING, STRING>,
                                                                                current_indicator INT,
                                                                                effective_date DATE,
                                                                                end_date DATE
                                                                            )
                                                                            USING DELTA; """
                }

   