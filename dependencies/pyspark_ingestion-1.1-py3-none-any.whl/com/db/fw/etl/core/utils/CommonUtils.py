import yaml
import logging


class CommonUtils():

    # Init method
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    # Validate if the Yaml structure is correct or not
    def validate_yaml(self, yaml_file_path):
        """
        Method to validate if the YAML structure is valid or not

        :parm yaml_file_path: absolute path of the yaml file
        
        """

        # Read YAML document from file
        with open(yaml_file_path, "r") as file:
            yaml_doc = file.read()

        # Parse YAML document and check for errors
        try:
            yaml_obj = yaml.safe_load(yaml_doc)
            self.logger.info("YAML is valid")
        except yaml.YAMLError as e:
            message = f"YAML is invalid: {e}"
            self.logger.error(message)
            raise Exception(message)
    
    def check_if_table_exists(self, database_name, table_name, spark) -> bool:
        """
        Method to check if table exists in database

        :param database_name: name of the database/schema to check
        :param table_name: name of the table to check
        :param spark: spark session
        :return: boolean is the return type

        """
        return spark.catalog.tableExists(f"{database_name}.{table_name}")