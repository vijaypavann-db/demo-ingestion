
class CONFIGS:   
    AVRO_READER_OPTIONS = [
                            'mergeSchema',
                            'pathGlobFilter',
                            'recursiveFileLookup',
                            'modifiedBefore',
                            'modifiedAfter'
                          ]
    PARQUET_READER_OPTIONS = [
                            'mergeSchema',
                            'int96RebaseMode'
                            'datetimeRebaseMode'
                            'pathGlobFilter',
                            'recursiveFileLookup',
                            'modifiedBefore',
                            'modifiedAfter'
                          ]
    ORC_READER_OPTIONS = [
                            'ignoreExtension',
                            'avroschema',
                            'datetimeRebaseMode',
                            'positionalFieldMatching',
                            'pathGlobFilter',
                            'recursiveFileLookup',
                            'modifiedBefore',
                            'modifiedAfter'
                          ]
    TEXT_READER_OPTIONS = [
                            'wholetext',
                            'lineSep',
                            'pathGlobFilter',
                            'recursiveFileLookup',
                            'modifiedBefore',
                            'modifiedAfter'
                          ]                      
                      


    CSV_READER_OPTIONS_DEFAULT = {"ignoreLeadingWhiteSpace" : "true","ignoreTrailingWhiteSpace" : "true"}
    
    CSV_READER_OPTIONS = [  'delimiter',
                            'sep',
                            'encoding',
                            'quote',
                            'escape',
                            'comment',
                            'header',
                            'inferSchema',
                            'enforceSchema',
                            'ignoreLeadingWhiteSpace',
                            'ignoreTrailingWhiteSpace',
                            'nullValue',
                            'nanValue',
                            'positiveInf',
                            'negativeInf',
                            'dateFormat',
                            'timestampFormat',
                            'timestampNTZFormat',
                            'maxColumns',
                            'maxCharsPerColumn',
                            'mode',
                            'columnNameOfCorruptRecord',
                            'multiLine',
                            'charToEscapeQuoteEscaping',
                            'samplingRatio',
                            'emptyValue',
                            'locale',
                            'lineSep',
                            'unescapedQuoteHandling',
                            'pathGlobFilter',
                            'recursiveFileLookup',
                            'modifiedBefore',
                            'modifiedAfter'
        ]
    JSON_READER_OPTIONS_DEFAULT = {"allowNumericLeadingZeros":"true","allowBackslashEscapingAnyCharacter":"true"}

    JSON_READER_OPTIONS = ['timeZone',
                            'primitivesAsString',
                            'prefersDecimal',
                            'allowComments',
                            'allowUnquotedFieldNames',
                            'allowSingleQuotes',
                            'allowNumericLeadingZero',
                            'allowBackslashEscapingAnyCharacter',
                            'mode',
                            'columnNameOfCorruptRecord',
                            'dateFormat',
                            'timestampFormat',
                            'timestampNTZFormat',
                            'multiLine',
                            'allowUnquotedControlChars',
                            'encoding',
                            'lineSep',
                            'samplingRatio',
                            'dropFieldIfAllNull',
                            'locale',
                            'allowNonNumericNumbers',
                            'ignoreNullFields',
                            'pathGlobFilter',
                            'recursiveFileLookup',
                            'modifiedBefore',
                            'modifiedAfter'
        ]