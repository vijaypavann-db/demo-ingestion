from com.db.fw.etl.core.common.Task import Task
from pyspark.sql.functions import lit, current_timestamp
from com.db.fw.etl.core.common.Commons import Commons
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS


class BaseProcessor(Task):
    def __init__(self, task_name, task_type):
        super.__init__(self, task_name, task_type)


class GenericProcessor(BaseProcessor):
    def __init__(self, name, type):
        Task.__init__(self, name, type)

    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.GenericProcessor ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            df = self.get_input_dataframe()

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)

            select_cols = None
            mask_cols = None

            if COMMON_CONSTANTS.MASK_COLUMNS in configs.keys():
                mask_cols = [item.strip() for item in configs.get(COMMON_CONSTANTS.MASK_COLUMNS).split(",")]

            if COMMON_CONSTANTS.SELECT_COLUMNS in configs.keys():
                select_cols = []
                for item in configs.get(COMMON_CONSTANTS.SELECT_COLUMNS).split(","):
                    col = item.strip()
                    if mask_cols and col in mask_cols:
                        col = f"mask({col}) AS {col}"
                    select_cols.append(col)

            df = df.selectExpr(select_cols)

            df = df.withColumn("enqueuedTime", lit(current_timestamp())).withColumn("dummy_col", lit(0.3))

            if COMMON_CONSTANTS.LIMIT in configs.keys():
                n_limit = int(configs.get(COMMON_CONSTANTS.LIMIT))
                df = df.limit(n_limit)

            self.set_output_dataframe(df)

            count_stats = df.count()
            self.add_facts("generic_processor row count", count_stats)

        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in GenericProcessor {} ".format(str(e)))


class SQLProcessor(BaseProcessor):
    def __init__(self, name, type):
        Task.__init__(self, name, type)

    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.SQLProcessor ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)

            custom_sql = None
            
            if COMMON_CONSTANTS.CUSTOM_SQL in configs.keys():
                custom_sql = configs.get(COMMON_CONSTANTS.CUSTOM_SQL)

            df = self.spark.sql(custom_sql)
            
            self.set_output_dataframe(df)
            
            count_stats = df.count()
            self.add_facts("sql_processor row count", count_stats)

        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in GenericProcessor {} ".format(str(e)))            





