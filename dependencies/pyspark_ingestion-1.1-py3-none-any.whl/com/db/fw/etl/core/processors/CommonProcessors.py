from com.db.fw.etl.core.common.Task import Task
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import lit, current_timestamp, expr, when, isnan, isnull, count, col
from com.db.fw.etl.core.common.Commons import Commons
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS
from com.db.fw.etl.core.exception.EtlExceptions import InvalidParamsException

class BaseProcessor(Task):
    def __init__(self, task_name, task_type):
        super.__init__(self, task_name, task_type)


class GenericProcessor(BaseProcessor):
    def __init__(self, name, type):
        Task.__init__(self, name, type)

    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.GenericProcessor ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            df = self.get_input_dataframe()

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)

            select_cols = None
            mask_cols = None

            if COMMON_CONSTANTS.MASK_COLUMNS in configs.keys():
                mask_cols = [item.strip() for item in configs.get(COMMON_CONSTANTS.MASK_COLUMNS).split(",")]

            if COMMON_CONSTANTS.SELECT_COLUMNS in configs.keys():
                select_cols = []
                for item in configs.get(COMMON_CONSTANTS.SELECT_COLUMNS).split(","):
                    col = item.strip()
                    if mask_cols and col in mask_cols:
                        col = f"mask({col}) AS {col}"
                    select_cols.append(col)

            df = df.selectExpr(select_cols)

            df = df.withColumn("enqueuedTime", lit(current_timestamp())).withColumn("dummy_col", lit(0.3))

            if COMMON_CONSTANTS.LIMIT in configs.keys():
                n_limit = int(configs.get(COMMON_CONSTANTS.LIMIT))
                df = df.limit(n_limit)

            self.set_output_dataframe(df)

            count_stats = df.count()
            self.add_facts("generic_processor row count", count_stats)

        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in GenericProcessor {} ".format(str(e)))


class SQLProcessor(BaseProcessor):
    def __init__(self, name, type):
        Task.__init__(self, name, type)

    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.SQLProcessor ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)

            custom_sql = None
            
            if COMMON_CONSTANTS.CUSTOM_SQL in configs.keys():
                custom_sql = configs.get(COMMON_CONSTANTS.CUSTOM_SQL)

            df = self.spark.sql(custom_sql)
            
            self.set_output_dataframe(df)
            
            count_stats = df.count()
            self.add_facts("sql_processor row count", count_stats)

        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in SQLProcessor {} ".format(str(e)))            

class DataValidationProcessor(BaseProcessor):
    """
    Class to perform Data Validation / Quality checks :
    Accepts metadata from processor configs and performs 
        i. Data Quality Checks (e.g., user_id must not be null)
        ii. Threshold Limit checks ( DOB column should contain data for min 70% of records). 
            If it falls below that terminate the Pipeline, Send an alert to the User.
    """
    def __init__(self, name, type):
        Task.__init__(self, name, type)

    def handle_not_null(self, df: DataFrame, df_cols: list):
        null_count_df = df.select([count(when(isnan(c) | isnull(c), c)).alias(c) for c in df_cols])
        null_count_df.show()
        null_counts = null_count_df.head()
        not_null_cols_violations = []
        
        for colm in df_cols:
            if null_counts[colm] > 0:
                print(f"`{colm}` has **`{null_counts[colm]}` null** values")
                not_null_cols_violations.append(colm)
        
        if len(not_null_cols_violations) > 0:
            # raise Exception(f"Not Null condition violated for cols...{','.join(not_null_cols_violations)}")
            Commons.printErrorMessage(f"Not Null condition violated for cols...{','.join(not_null_cols_violations)}")


    def handle_null_threshold(self, df: DataFrame, threshold_rules: dict):
        df_count = df.count()
        df_cols = threshold_rules.keys()
        
        null_count_df = df.select([count(when(isnan(c) | isnull(c), c)).alias(c) for c in df_cols])
        null_count_df.show()
        null_pct_df = null_count_df.select([ ( (col(c) * 100) / df_count).alias(c) for c in df_cols])
        null_pct_df.show()
        
        null_counts = null_count_df.head()
        null_pct_counts = null_pct_df.head()
        null_vals_threshold_violations = []

        for colm in df_cols:
            if null_pct_counts[colm] > threshold_rules[colm]:
                print(f""" `{colm}` has **`{null_pct_counts[colm]}% [{null_counts[colm]}] null** values
                        exceeding allowed Threshold `{threshold_rules[colm]}%` """)
                null_vals_threshold_violations.append(colm)
            else:
                print(f""" `{colm}` has **`{null_pct_counts[colm]}% [{null_counts[colm]}] null** values
                        within allowed Threshold `{threshold_rules[colm]}%` """)
            
        if len(null_vals_threshold_violations) > 0:
            # raise Exception(f"Null values Threshold violated for cols...{','.join(null_vals_threshold_violations)} ")
            Commons.printErrorMessage(f"Null values Threshold violated for cols...{','.join(null_vals_threshold_violations)} ")

    def parse_data_rules(self, data_rules: str):
        data_rules_dict = {}
        for data_rule_cond in data_rules.split("-||-"):
            ary = data_rule_cond.split("==")
            data_rule_name = ary[0].strip()
            data_rule = ary[1].strip()
            if data_rule.find("{") >= 0:
                data_rules_dict[data_rule_name] = Commons.get_json_obj(data_rule)
            else:
                data_rules_dict[data_rule_name] = (data_rule.split("-,-"))

        [print(k, type(k), v, type(v)) for k, v in data_rules_dict.items()]
        return data_rules_dict


    def apply_data_rules(self, df: DataFrame, data_rules_dict: dict):
        for k, v in data_rules_dict.items():
            print(k, type(k), v, type(v))
            if k == "not_null" and type(v) == list:
                self.handle_not_null(df, v)
            elif k == "null_threshold" and type(v) == dict:
                self.handle_null_threshold(df, v)  
            else:
                print(k, v)  
                raise InvalidParamsException(self.task_name, self.pipeline_name, self.input_options)

    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.DataValidationProcessor ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)

            data_rules = None
            
            if COMMON_CONSTANTS.DATA_RULES_COLUMN in configs.keys():
                data_rules = configs.get(COMMON_CONSTANTS.DATA_RULES_COLUMN)

            df = self.get_input_dataframe()
            
            data_rules_dict = self.parse_data_rules(data_rules)
            self.apply_data_rules(df, data_rules_dict)
            
            self.set_output_dataframe(df)
            
            count_stats = df.count()
            self.add_facts("DataValidationProcessor row count", count_stats)

        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in DataValidationProcessor {} ".format(str(e)))            

class RulesProcessor(BaseProcessor):
    """
    Class to apply rules on DataFrame :
    Reads Rules from processor configs metadata.
        i. Transforms the rules to Column Expressions
        ii. Adds a new column "Rule Name" to the DataFrame with `Column Expr`
    """
    def __init__(self, name, type):
        Task.__init__(self, name, type)

    def get_rule_expr(self, rule_conds: dict): 
        list = [f" \t WHEN {k} THEN '{v}' " for k, v in rule_conds.items()]
        conditions = "\n".join(list)
        column = f"CASE \n {conditions} \n ELSE 'Re-Assess' \n END"
        # print(column)
        return column
    
    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.RulesProcessor ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)

            rules = None
            
            if COMMON_CONSTANTS.RULES_COLUMN in configs.keys():
                rules = configs.get(COMMON_CONSTANTS.RULES_COLUMN)

            rules_dict = {}
            for rule in rules.split("-||-"):
                ary = rule.split("==")
                rule_name = ary[0].strip()
                rule_dict = Commons.get_json_obj(ary[1].strip())
                # print(rule_name, rule_dict)
                rules_dict[rule_name] = rule_dict
            
            df = self.get_input_dataframe()
            
            for rule_name, rule_dict in rules_dict.items():
                rule_expr = self.get_rule_expr(rule_dict)
                print(rule_name, rule_expr)
                df = df.withColumn(rule_name, expr(rule_expr))

            self.set_output_dataframe(df)
            
            df_cols_len = len(df.columns)
            self.add_facts("df columns Size", df_cols_len)

        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in RulesProcessor {} ".format(str(e)))            




