from pyspark.sql import SparkSession
import uuid
from com.db.fw.etl.core.exception.EtlExceptions import InvalidParamsException
from com.db.fw.etl.core.common.Commons import Commons
from com.db.fw.etl.core.common.Constants import  COMMON_CONSTANTS

class IOService:

    def __init__(self):
        self.spark = SparkSession.builder.getOrCreate()

    IO_SERVICE_STATUS = True

    def cleanup_msg(self, message):
        if message is not None:
            message = message.replace("'", "")
        return message

    def store_pipeline_status(self, pipeline_instance_id, status, time, error):
        if not IOService.IO_SERVICE_STATUS:
            return None

        tmp_uuid = str(uuid.uuid1())
        error_msg = self.cleanup_msg(str(error))

        sql_stmt = f""" INSERT INTO  {COMMON_CONSTANTS.METADATA_DB}.pipeline_status
                                                    (id,
                                                    pipeline_id,
                                                    status,
                                                    updated_at,
                                                    error_msg)
                            VALUES ('{tmp_uuid}',
                                    '{pipeline_instance_id}',
                                    '{status}',
                                    '{time}',
                                    '{error_msg}'
                                   ); """ 
                            
        self.spark.sql(sql_stmt)

    def store_task_status(self, pipeline_instance_id, name, status, time, error):
        if not IOService.IO_SERVICE_STATUS:
            return None
        tmp_uuid = str(uuid.uuid1())
        error_msg = self.cleanup_msg(str(error))

        sql_stmt = f""" INSERT INTO  {COMMON_CONSTANTS.METADATA_DB}.task_status
                                                    (task_id,
                                                    pipeline_id,
                                                    task_name,
                                                    status,
                                                    start_time,
                                                    end_time,
                                                    updated_at,
                                                    error_msg)
                            VALUES ('{tmp_uuid}',
                                    '{pipeline_instance_id}',
                                    '{name}',
                                    '{status}',
                                    '{time}',
                                    '{time}',
                                    '{time}',
                                    '{error_msg}'
                                   ); """ 
        
        self.spark.sql(sql_stmt)

    def store_operational_stats(self, pipeline_instance_id, pipeline_name, task_name, stats, time, batch_id = -1):
        # if IOService.IO_SERVICE_STATUS == False :
        #     return None;
        # print("store_operation_stats I am here inside")
        INSERT_STMT = f"INSERT INTO  {COMMON_CONSTANTS.METADATA_DB}.operational_stats VALUES "
        comma_sept_for_values = ""
        for stat_name, state_value in stats.items():
            values_stmt = "{} ( '{}', '{}','{}','{}','{}','{}',{})  ".format(comma_sept_for_values,
                                                                             pipeline_instance_id, pipeline_name,
                                                                             task_name, stat_name, state_value, time,
                                                                             batch_id)
            comma_sept_for_values = ","

            INSERT_STMT = INSERT_STMT + values_stmt

        Commons.printInfoMessage(INSERT_STMT)
        self.spark.sql(INSERT_STMT)

    def store_pipeline_metadata(self, out_pip_id, out_name, db_name, entity_name, pipeline_type):
        if not IOService.IO_SERVICE_STATUS:
            return None
        
        time = Commons.get_current_time()
        
        sql_stmt = f"""INSERT INTO {COMMON_CONSTANTS.METADATA_DB}.pipeline_metadata (pipeline_id, 
                                                                                     pipeline_name,
                                                                                     db_name, 
                                                                                     entity_name,  
                                                                                     pipeline_type,
                                                                                     insert_time
                                                                                    )
                                                                        VALUES ('{out_pip_id}', 
                                                                                '{out_name}',
                                                                                '{db_name}',
                                                                                '{entity_name}',
                                                                                '{pipeline_type}',
                                                                                '{time}'
                                                                               ); """
        
        self.spark.sql(sql_stmt)

    # TODO
    def store_pipeline_options(self, out_pip_id, out_name, out_jsons):
        if not IOService.IO_SERVICE_STATUS:
            return None
        sql_stmt = "INSERT INTO  {}.pipeline_metadata  VALUES('{}', '{}', '{}')".format(COMMON_CONSTANTS.METADATA_DB,
                                                                                              out_pip_id, out_name,
                                                                                              out_jsons)
        
        sql_stmt = f"""INSERT INTO {COMMON_CONSTANTS.METADATA_DB}.pipeline_metadata (pipeline_id, 
                                                                                     pipeline_name,
                                                                                     db_name, 
                                                                                     entity_name,  
                                                                                     pipeline_type,
                                                                                     insert_time,
                                                                                     updated_at
                                                                                    )  
                       
                                                                        VALUES ('{out_pip_id}', 
                                                                                '{out_name}',
                                                                                '{out_jsons}'
                                                                               ); """
        
        self.spark.sql(sql_stmt)   

    def get_pipeline_metadata(self, pipeline_name, task_name):

        sql_stmt = f"select * from {COMMON_CONSTANTS.METADATA_DB}.pipeline_metadata  where pipeline_name == '{pipeline_name}' "

        meta_values = self.spark.sql(sql_stmt).collect()
        
        if len(meta_values) <= 0:
            raise InvalidParamsException(task_name, pipeline_name, {})

        pipeline_id = meta_values[0].pipeline_id
        pipeline_name = meta_values[0].pipeline_name
        node_definition = meta_values[0].node_info
        return pipeline_id, pipeline_name, node_definition
