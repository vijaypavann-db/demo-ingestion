from datetime import datetime
import random
import string
import json

class Commons:
    """
        Contains Common functions such as logging & validations, that are being used across the framework
    """
    FLOW_PRINT_ON = True
    DEBUG_PRINT_ON = False
    ERROR_PRINT_ON = True

    # Formatted Current Timestamp
    @staticmethod
    def get_current_time():
        x = datetime.now()
        curr_time = x.strftime("%Y-%m-%d %H:%M:%S.%f")
        return curr_time

    @staticmethod
    def printFlowMessage(message):
        """ 
            Prints the message, if `FLOW_PRINT_ON` is set to `True`. 
            Used for :
                - understanding the Code Flow [ Reader -> Processor -> Writer ] 
                - prints the classes that were initialized for the run.
        """
        if Commons.FLOW_PRINT_ON:
            print(message)

    @staticmethod
    def printInfoMessage(message):
        """ 
            Prints the message, if `DEBUG_PRINT_ON` is set to `True`. 
            Used for debugging the Code and prints the details of Task.
        """
        if Commons.DEBUG_PRINT_ON:
            print(message)

    @staticmethod
    def printErrorMessage(message):
        """ 
            Prints the message, if `ERROR_PRINT_ON` is set to `True`. 
            Used for printing the Exception messages.
        """
        if Commons.ERROR_PRINT_ON:
            print(message)
    
    # Returns random lowercase string of given `length`
    @staticmethod
    def upper_lower_random_string(length):
        result = ''.join(
            (random.choice(string.ascii_lowercase) for x in range(length)))
        return result

    @staticmethod
    def optionsValidations(reader_options, file_format_options):
        """
            Validates a list of reader options provided by the user to read files.Raises an error if the option doen't exists

            :param reader_options: A list of reader options to be validated.
            :param file_format_options: A list of valid options for the respective file format.
            :return: None 
        """
        for option in reader_options:
              if option not in file_format_options:
                print(f'Invalid option passed - {option} ') 
                #raise InsufficientParamsException(self.task_name, self.pipeline_name, self.input_options,"Invalid options for reader.. ")
                raise ValueError(f"Invalid option '{option}'") 

    @staticmethod
    def get_json_obj(jsonStr: str):
        jsonObj = json.loads(jsonStr)
        return jsonObj