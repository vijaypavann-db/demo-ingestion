class COMMON_CONSTANTS:

    # Input Options
    TABLE_NAME = "table_name"
    DB_NAME = "db_name"
    OPTIONS = "options"
    CONFIGS = "configs"
    FORMAT = "format"
    PATH = "path"

    # Writer Stream Configs
    CHECK_POINT_LOCATION = "checkpointLocation"
    TRIGGER_TIME = "trigger_time"
    WRITER_TYPE = "writer_type"
    
    # Delta Writer Settings
    APPEND = "append"
    OVERWRITE = "overwrite"
    MERGE = "merge"
    UPDATE = "update"
    DELETE = "delete"
    

    DO_UPDATE = "do_update"
    DO_DELETE = "do_delete"
    DO_INSERT = "do_insert"
    
    WHERE = "where"
    MERGE_CONDITION = "merge_condition"
    UPDATE_CONDITION = "update_condition"
    DELETE_CONDITION = "delete_condition"
    

    # Node Status
    STARTED = "started"
    FINISHED = "finished"
    ERROR_FINISHED = "error_finished"

    # Log Level
    ERROR = "error"
    INFO = "INFO"
    WARN = "WARN"
    
    # Metadata
    METADATA_DB = "demo_metadata"
    PIPELINE_METADATA_TABLE = "pipeline_metadata" 
    PIPELINE_OPTIONS_TABLE = "pipeline_options"
    TASKS_TABLE = "pipeline_tasks"
    DEPENDENCIES_TABLE = "pipeline_dependencies"

    # Generic Processor
    MASK_COLUMNS = "mask_columns"
    SELECT_COLUMNS = "select_columns"

    # SQL PROCESSOR
    CUSTOM_SQL = "custom_sql"

    LIMIT = "limit"