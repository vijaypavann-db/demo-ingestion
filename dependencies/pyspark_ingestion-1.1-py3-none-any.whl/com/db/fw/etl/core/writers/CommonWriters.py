from com.db.fw.etl.core.exception.EtlExceptions import *
from com.db.fw.etl.core.common.Task import Task
from com.db.fw.etl.core.writers.CommonWritingUtils import *


class BaseWriter(Task):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)


class DeltaWriter(BaseWriter):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):

        writer_configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
        writer_options = self.input_options.get("options")

        mode = writer_configs.get("mode", None)

        inputDf = self.get_input_dataframe()

        if mode == COMMON_CONSTANTS.APPEND:
            delta_insert(self.spark, inputDf, self.input_options, COMMON_CONSTANTS.APPEND)
        elif mode == COMMON_CONSTANTS.OVERWRITE:
            delta_insert(self.spark, inputDf, self.input_options, COMMON_CONSTANTS.OVERWRITE)
        elif mode == COMMON_CONSTANTS.DELETE:
            delta_delete(self.spark, options=self.input_options)
        elif mode == COMMON_CONSTANTS.UPDATE:
            delta_update(self.spark, inputDf, self.input_options)
        elif mode == COMMON_CONSTANTS.MERGE:
            delta_merge(self.spark, inputDf, self.input_options)
        else:
            raise InsufficientParamsException(
                self.task_name, self.pipeline_name, str(self.input_options))


class ConsoleWriter(BaseWriter):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        final_df = self.get_input_dataframe()
        if final_df is None or final_df.isStreaming:
            pass
        else:
            final_df.show(10, truncate=False)

            # .writeStream.format("console")\
            # .outputMode("append").start()
