from com.db.fw.etl.core.common.Constants import *
from com.db.fw.etl.core.common.Commons import Commons

def delta_insert(spark, df, input_options, mode, task_name):
    
    writer_configs = input_options.get(COMMON_CONSTANTS.CONFIGS)
    writer_options = input_options.get(COMMON_CONSTANTS.OPTIONS)

    db_name = writer_configs.get(COMMON_CONSTANTS.DB_NAME)
    table_name = writer_configs.get(COMMON_CONSTANTS.TABLE_NAME)
    writer_type = writer_configs.get(COMMON_CONSTANTS.WRITER_TYPE)

    Commons.printInfoMessage(f"delta_insert {str(input_options)} ")

    if writer_type is not None and writer_type.upper() == "STREAM":

        Commons.printFlowMessage("****** DataFrame Stream Writer ******")

        df_writer = df.writeStream \
            .format("delta") \
            .outputMode(mode)

        check_point = writer_configs.get(COMMON_CONSTANTS.CHECK_POINT_LOCATION, None)

        if check_point is not None:
            df_writer = df_writer.option("checkpointLocation", check_point)

        trigger_time = writer_configs.get(COMMON_CONSTANTS.TRIGGER_TIME, None)
        if trigger_time is not None:
            df_writer = df_writer.trigger(processingTime=str(trigger_time))

        df_writer.toTable(f"{db_name}.{table_name}")

    else:

        Commons.printFlowMessage(f"****** DataFrame Batch Writer ****** {db_name} {table_name} {mode}")

        df_writer = df.write \
            .format("delta") \
            .mode(mode)

        if writer_options is not None:
            df_writer = df_writer.options(**writer_options)

        df_writer.option("mergeSchema", "true").saveAsTable(f"{db_name}.{table_name}")
    
        df.createOrReplaceTempView(task_name)
        execMsg = f"""****** View `{task_name}` created... """
        Commons.printFlowMessage(execMsg)
    
    Commons.printFlowMessage(f"### Table Write Succedeed!! `{db_name}.{table_name}`")
    

def delta_delete(spark, df, input_options):
    
    writer_configs = input_options.get(COMMON_CONSTANTS.CONFIGS)

    db_name = writer_configs.get(COMMON_CONSTANTS.DB_NAME)
    table_name = writer_configs.get(COMMON_CONSTANTS.TABLE_NAME)
    where_condition = writer_configs.get(COMMON_CONSTANTS.WHERE, None)

    sql = f"DELETE FROM {db_name}.{table_name}"

    if where_condition is not None:
        sql = sql + f"Where {where_condition}"

    spark.sql(sql)


def delta_update(spark, df, options):
    print("go for update ")


"""
    MERGE INTO target_table_name [target_alias]
    USING source_table_reference [source_alias]
    ON merge_condition
    [ WHEN MATCHED [ AND condition ] THEN matched_action ] [...]
    [ WHEN NOT MATCHED [ AND condition ]  THEN not_matched_action ] [...]

    matched_action
    { DELETE |
    UPDATE SET * |
    UPDATE SET { column1 = value1 } [, ...] }

    not_matched_action
    { INSERT * |
    INSERT (column1 [, ...] ) VALUES (value1 [, ...])
    """


def delta_merge(spark, df, input_options):
    source = Commons.upper_lower_random_string(15)
    df.createOrReplaceTempView(source)

    writer_configs = input_options.get(COMMON_CONSTANTS.CONFIGS)
    writer_options = input_options.get(COMMON_CONSTANTS.OPTIONS)

    db_name = writer_configs.get(COMMON_CONSTANTS.DB_NAME)
    table_name = writer_configs.get(COMMON_CONSTANTS.TABLE_NAME)
    merge_condition = writer_configs.get(COMMON_CONSTANTS.MERGE_CONDITION)

    #target = "{}.{}".format(db_name, table_name)
    merge_condition = "".join(merge_condition).format("tgt", "src")

    do_update = writer_configs.get(COMMON_CONSTANTS.DO_UPDATE, None)
    do_delete = writer_configs.get(COMMON_CONSTANTS.DO_DELETE, None)
    do_insert = writer_configs.get(COMMON_CONSTANTS.DO_INSERT, None)

    print("Merge params " + str(writer_options))

    merge_sql = " MERGE INTO {}.{} {}".format(db_name, table_name, "tgt")
    merge_sql = merge_sql + " USING {} {} ON {} ".format(source, "src", merge_condition)

    # column selection is pending
    if do_update is not None:
        update_condition = ""
        if COMMON_CONSTANTS.UPDATE_CONDITION in writer_configs.keys():
            update_condition = "AND " + writer_configs.get(COMMON_CONSTANTS.UPDATE_CONDITION)
        merge_sql = merge_sql + " WHEN MATCHED {} THEN UPDATE SET * ".format(update_condition)

    if do_delete is not None:
        delete_condition = ""
        if COMMON_CONSTANTS.DELETE_CONDITION in writer_configs.keys():
            delete_condition = "AND " + writer_configs.get(COMMON_CONSTANTS.DELETE_CONDITION)
        merge_sql = merge_sql + " WHEN MATCHED {} THEN DELETE ".format(delete_condition)

    # column selection is pending
    if do_insert is not None:
        merge_sql = merge_sql + " WHEN NOT MATCHED THEN INSERT * "

    print("SQL {} ".format(merge_sql))

    output = None

    output = spark.sql(merge_sql)

    spark.catalog.dropTempView(source)

    return output
