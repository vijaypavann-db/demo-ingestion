import logging
import uuid

from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import *

from com.db.fw.etl.core.pipeline.PipelineBuilder import *
from com.db.fw.etl.core.common.DeltaStatLogger import IOService
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS
from com.db.fw.etl.core.common.Commons import Commons

class PipelineUtils:

    metadata_db = COMMON_CONSTANTS.METADATA_DB
    
    pipeline_metadata_tbl = COMMON_CONSTANTS.PIPELINE_METADATA_TABLE
    pipeline_options_tbl = COMMON_CONSTANTS.PIPELINE_OPTIONS_TABLE

    def __init__(self, spark: SparkSession):
        self.spark = spark
    
    def buildPipelineUsingRunId(self, run_id: str):
        
        options = (self.spark.read.table(f"{self.metadata_db}.{self.pipeline_options_tbl}")
                        .filter(f"run_id == '{run_id}'") ).alias("opt")
        
        metadata = self.spark.read.table(f"{self.metadata_db}.{self.pipeline_metadata_tbl}").alias("met")
        
        pipeline_details = (metadata
                            .join(options, metadata["pipeline_id"] == options["pipeline_id"], "inner")
                            .drop("opt.pipeline_id")
                            .head())
        
        Commons.printInfoMessage(pipeline_details)

        return self.pipelineBuilder(pipeline_details)
    

    def get_reader_task(self, reader_configs):
        """
            Get Reader task based on the file format
        """

        file_format = reader_configs["format"]

        task = PipelineNodeBuilder.GENERIC_BATCH_READER

        reader_tasks = {
                "auto_loader": PipelineNodeBuilder.AUTO_LOADER, 
                "csv" : PipelineNodeBuilder.CSV_READER, 
                "text" : PipelineNodeBuilder.TEXT_READER, 
                "orc" : PipelineNodeBuilder.ORC_READER, 
                "avro" : PipelineNodeBuilder.AVRO_READER, 
                "event_hubs_batch" : PipelineNodeBuilder.EVENT_HUBS_BATCH_READER,
                "event_hubs" : PipelineNodeBuilder.EVENT_HUBS_READER,
                "json" : PipelineNodeBuilder.JSON_READER,
                "kafka": PipelineNodeBuilder.KAFKA_READER,
                "parquet": PipelineNodeBuilder.PARQUET_READER,
                "rdbms" : PipelineNodeBuilder.RDMS_READER
                }
        
        return reader_tasks.get(file_format, task)

    def get_writer_task(self, writer_configs):

        format = writer_configs.get("format", "delta")
        task = PipelineNodeBuilder.DELTA_WRITER
        writer_tasks = {
                        "stream_console": PipelineNodeBuilder.STREAM_CONSOLE_WRITER,
                        "kafka": PipelineNodeBuilder.KAFKA_WRITER
        }
        return writer_tasks.get(format, task)
    
    def pipelineBuilder(self, pipeline_details: Row): 

        # Pipeline Info       
        pipeline_id = pipeline_details["pipeline_id"]
        run_id = pipeline_details["run_id"]

        # Entity Info
        database = pipeline_details["db_name"]
        entity_name = pipeline_details["entity_name"]
        
        # Reader
        reader_configs = pipeline_details['reader_configs']
        reader_options = pipeline_details['reader_options']
        file_format = reader_configs["format"]

        # TODO add Loggers for Options 
        Commons.printInfoMessage(f"reader_configs {reader_configs} \n reader_options {reader_options} ")
        
        # Processor
        Commons.printInfoMessage(f"processor_options {pipeline_details['processor_options']}")

        # Writer
        writer_configs = pipeline_details['writer_configs']
        writer_options = pipeline_details['writer_options']
        
        writer_configs = writer_configs | {COMMON_CONSTANTS.DB_NAME : database, 
                                           COMMON_CONSTANTS.TABLE_NAME : entity_name}

        Commons.printInfoMessage(f"writer_configs {writer_configs} \n writer_options {writer_options}")

        reader_task = self.get_reader_task(reader_configs)
            
        reader = (PipelineNodeBuilder() 
                    .set_name(f"{file_format}_df_reader_{run_id}") 
                    .set_type(reader_task) 
                    .add_input_option("configs", reader_configs)
                    .add_input_option("options", reader_options)
                    .build() )
        
        writer_format = writer_configs.get("format","delta")

        writer_task = self.get_writer_task(writer_configs)
                    
        writer = (PipelineNodeBuilder() 
                    .set_name(f"{writer_format}_writer_{run_id}") 
                    .set_type(writer_task) 
                    .add_input_option(COMMON_CONSTANTS.OPTIONS, writer_options)
                    .add_input_option(COMMON_CONSTANTS.CONFIGS, writer_configs)
                    .build() )

        io_service = IOService()
        logger = logging.getLogger(__name__)

        pipeline = (PipelineBuilder(self.spark, entity_name, logger, pipeline_id, io_service) 
                    .add_node(reader) 
                    # .add_node_after(reader.name, processor)
                    .add_node_after(reader.name, writer)
                    .build() )

        pip_id,name,meta_jsons = PipelineBuilder.get_json_dump(pipeline)
        print(pip_id)
        print(name)
        print(meta_jsons)

        # TODO: Store meta_jsons in `pipeline_options` table ??
        return pipeline
