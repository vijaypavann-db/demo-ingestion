import os
import logging

import yaml
from pyspark.sql.functions import *

from com.db.fw.etl.core.common.Constants import *
from com.db.fw.etl.core.utils.CommonUtils import *


class PrepareDelta():

    # Init method
    def __init__(self, spark, yaml_file_dir):
        self.spark = spark
        self.yaml_file_dir = yaml_file_dir
        self.logger = logging.getLogger(__name__)

    def yaml_to_dataframe(self, yaml_file_path):

        # Validate YAML file before converting to dataframe

        CommonUtils().validate_yaml(yaml_file_path)

        # Read YAML file and load as dictionary
        with open(yaml_file_path, 'r') as file:
            yaml_dict = yaml.load(file, Loader=yaml.FullLoader)

        # Create tasks DataFrame
        tasks_list = yaml_dict['tasks']
        
        pipeline_id_col = hash(lit(yaml_dict['pipeline_name']))
        pipeline_name_col = lit(yaml_dict['pipeline_name'])

        tasks_df = self.spark.createDataFrame(tasks_list)
        tasks_df = (tasks_df
                            .withColumn('pipeline_id', pipeline_id_col)
                            .withColumn('pipeline_name', pipeline_name_col) )        

        tasks_df = (tasks_df
                            .selectExpr("uuid() as task_id", "task_name", "pipeline_id", "pipeline_name", "task_configs", "task_options") )

        # Create dependencies DataFrame
        dependencies_dict = yaml_dict['dependencies']
        dependencies_list = []
        incr = 0
        for (task, dependents) in dependencies_dict.items():
            if isinstance(dependents, str):
                dependents = [dependents]
            for dependent in dependents:
                incr += 1
                dependencies_list.append((task, dependent, incr))

        dependencies_df = self.spark.createDataFrame(dependencies_list, ['parent', 'child', 'sequence'])

        dependencies_df = (dependencies_df
                                        .withColumn('pipeline_id', pipeline_id_col)
                                        .withColumn('pipeline_name', pipeline_name_col) )

        dependencies_df = (dependencies_df
                                        .select("parent", "child", "sequence", 
                                        "pipeline_id", "pipeline_name") )
        
        return tasks_df, dependencies_df
    
    def createEmptyDF(self):
        # set the intial schema for the tasks and dependency dataframes         
                  
        tasks_schema = """task_id STRING, task_name STRING, pipeline_id STRING, pipeline_name STRING, task_configs MAP<STRING, STRING>, task_options MAP<STRING, STRING>"""
        
        dependency_schema = """parent STRING, child STRING, sequence BIGINT, pipeline_id STRING, pipeline_name STRING"""

        # create empty dataframe for tasks dataframe so multiple dfs can be union
        tasks_df = self.spark.createDataFrame([], schema = tasks_schema)
        
        # create empty dataframe for dependency dataframe so multiple dfs can be union
        dependencies_df = self.spark.createDataFrame([], schema = dependency_schema)

        return tasks_df, dependencies_df
    
    def writeTasksDF(self, tasks_df):

        if CommonUtils().check_if_table_exists(COMMON_CONSTANTS.METADATA_DB, COMMON_CONSTANTS.TASKS_TABLE, self.spark):
            self.logger.info("exists")
            print(" exists")
            ################# SQl WAY #########################

            # Register the tasks_df and tasksTable_df as temporary views
            tasks_df.createOrReplaceTempView("updates")
            self.spark.read.table(F"{COMMON_CONSTANTS.METADATA_DB}.{COMMON_CONSTANTS.TASKS_TABLE}").createOrReplaceTempView("tasks")


            # Generate SQL query for newDataToInsert
            newDataToInsertQuery = """
            SELECT
                updates.*
            FROM
                updates
            JOIN
                tasks
            ON
                updates.pipeline_name = tasks.pipeline_name
                AND updates.pipeline_id = tasks.pipeline_id
                AND updates.task_name = tasks.task_name
            WHERE
                tasks.current_indicator = 1
                AND (
                    (MAP_KEYS(updates.task_configs) <> MAP_KEYS(tasks.task_configs) OR MAP_VALUES(updates.task_configs) <> MAP_VALUES(tasks.task_configs))
                    OR
                    (MAP_KEYS(updates.task_options) <> MAP_KEYS(tasks.task_options) OR MAP_VALUES(updates.task_options) <> MAP_VALUES(tasks.task_options))
                )
            """

            # Execute the query and store the result in newDataToInsert DataFrame
            newDataToInsert = self.spark.sql(newDataToInsertQuery)

            # Register the newDataToInsert and tasks_df as temporary views
            newDataToInsert.createOrReplaceTempView("newDataToInsert")

            # Generate SQL query for staging the update
            stagedUpdatesQuery = """
            SELECT
                NULL AS mergekey1,
                NULL AS mergekey2,
                NULL AS mergekey3,
                *
            FROM
                newDataToInsert
            UNION ALL
            SELECT
                pipeline_id AS mergekey1,
                pipeline_name AS mergekey2,
                task_name AS mergekey3,
                *
            FROM
                updates
            """

            # Execute the query and store the result in stagedUpdates DataFrame
            stagedUpdates = self.spark.sql(stagedUpdatesQuery)
            stagedUpdates.createOrReplaceTempView("staged_updates")

            # Generate SQL query for SCD Type 2 operation using merge
            mergeQuery = f"""
            MERGE INTO {COMMON_CONSTANTS.METADATA_DB}.{COMMON_CONSTANTS.TASKS_TABLE} AS tasks
            USING (
                SELECT
                    mergekey1,
                    mergekey2,
                    mergekey3,
                    *
                FROM
                    staged_updates
            ) AS staged_updates
            ON
                tasks.pipeline_id = staged_updates.mergekey1
                AND tasks.pipeline_name = staged_updates.mergekey2
                AND tasks.task_name = staged_updates.mergekey3
            WHEN MATCHED AND tasks.current_indicator = 1
                AND (
                    (MAP_KEYS(staged_updates.task_configs) <> MAP_KEYS(tasks.task_configs) OR MAP_VALUES(staged_updates.task_configs) <> MAP_VALUES(tasks.task_configs))
                    OR
                    (MAP_KEYS(staged_updates.task_options) <> MAP_KEYS(tasks.task_options) OR MAP_VALUES(staged_updates.task_options) <> MAP_VALUES(tasks.task_options))
                )
            THEN UPDATE SET
                current_indicator = 0,
                end_date = staged_updates.effective_date
            WHEN NOT MATCHED
            THEN INSERT *
            """

            # Execute the merge query
            self.spark.sql(mergeQuery)

        else:
            self.logger.info("not exists")
            print("not exists")
            tasks_df.write.format("delta").mode("overwrite").saveAsTable(
                f"{COMMON_CONSTANTS.METADATA_DB}.{COMMON_CONSTANTS.TASKS_TABLE}")
    
    def writeDependencyDF(self, dependencies_df):

        
        if CommonUtils().check_if_table_exists(COMMON_CONSTANTS.METADATA_DB, COMMON_CONSTANTS.DEPENDENCIES_TABLE, self.spark):
            self.logger.info("exists")
            print(("exists"))    
            #################### SQL WAY ######################

            # Register the tasks_df and tasksTable_df as temporary views
            dependencies_df.createOrReplaceTempView("updates")
            self.spark.read.table(F"{COMMON_CONSTANTS.METADATA_DB}.{COMMON_CONSTANTS.DEPENDENCIES_TABLE}").createOrReplaceTempView("dependency")

            newDataToInsertQuery = """
            SELECT
                updates.*
            FROM
                updates
            JOIN
                dependency
            ON
                updates.pipeline_name = dependency.pipeline_name
                AND updates.pipeline_id = dependency.pipeline_id
                AND updates.sequence = dependency.sequence
            WHERE
                dependency.current_indicator = 1
                AND (updates.parent <> dependency.parent OR updates.child <> dependency.child)
            """

            # Execute the query and store the result in newDataToInsert DataFrame
            newDataToInsert = self.spark.sql(newDataToInsertQuery)

            # Register the newDataToInsert and tasks_df as temporary views
            newDataToInsert.createOrReplaceTempView("newDataToInsert")

            stagedUpdatesQuery = """
            SELECT
                NULL AS mergekey1,
                NULL AS mergekey2,
                NULL AS mergekey3,
                *
            FROM
                newDataToInsert
            UNION ALL
            SELECT
                pipeline_id AS mergekey1,
                pipeline_name AS mergekey2,
                sequence AS mergekey3,
                *
            FROM
                updates
            """

            # Execute the query and store the result in stagedUpdates DataFrame
            stagedUpdates = self.spark.sql(stagedUpdatesQuery)
            stagedUpdates.createOrReplaceTempView("staged_updates")

            # Generate SQL query for SCD Type 2 operation using merge
            mergeQuery = f"""
            MERGE INTO {COMMON_CONSTANTS.METADATA_DB}.{COMMON_CONSTANTS.DEPENDENCIES_TABLE} AS dependency
            USING (
                SELECT
                    mergekey1,
                    mergekey2,
                    mergekey3,
                    *
                FROM
                    staged_updates
            ) AS staged_updates
            ON
                dependency.pipeline_id = staged_updates.mergekey1
                AND dependency.pipeline_name = staged_updates.mergekey2
                AND dependency.sequence = staged_updates.mergekey3
            WHEN MATCHED AND dependency.current_indicator = 1
                AND (staged_updates.parent <> dependency.parent OR staged_updates.child <> dependency.child)
            THEN UPDATE SET
                current_indicator = 0,
                end_date = staged_updates.effective_date
            WHEN NOT MATCHED
            THEN INSERT *
            """

            # Execute the merge query
            self.spark.sql(mergeQuery)

        else:
            self.logger.info("not exists")
            print("not exists")
            dependencies_df.write.format("delta").mode("overwrite").saveAsTable(
                f"{COMMON_CONSTANTS.METADATA_DB}.{COMMON_CONSTANTS.DEPENDENCIES_TABLE}")


    # Start or entry point for the whole class
    def start(self):

        # Get the list of existing files from the input directory
        file_list = []
        with os.scandir(self.yaml_file_dir) as entries:
            for entry in entries:
                file_list.append(entry.name)

        # raise exception if there are no files in directory
        if len(file_list) == 0:
            raise Exception(f"{self.yaml_file_dir} is empty")
        
        #create empty dataframe
        tasks_df, dependencies_df = self.createEmptyDF()

        # for the listed files call yaml_to_dataframe fucntion to conert yaml to dataframe
        for file_name in file_list:
            res = self.yaml_to_dataframe(f"{self.yaml_file_dir}/{file_name}")
            tasks_df = tasks_df.unionByName(res[0])
            dependencies_df = dependencies_df.unionByName(res[1])

        # Add operational columns to the dataframes

        tasks_df = (
            tasks_df.withColumn("current_indicator", lit(1))
            .withColumn("effective_date", lit(current_date()))
            .withColumn("end_date", lit(None).cast("date"))
            .withColumn("task_configs", when(col("task_configs").isNull(), lit(create_map())).otherwise(col("task_configs")))
            .withColumn("task_options", when(col("task_options").isNull(), lit(create_map())).otherwise(col("task_options")))
        )

        dependencies_df = (
            dependencies_df.withColumn("current_indicator", lit(1))
            .withColumn("effective_date", lit(current_date()))
            .withColumn("end_date", lit(None).cast("date"))
        )

        self.writeTasksDF(tasks_df)
        self.writeDependencyDF(dependencies_df)