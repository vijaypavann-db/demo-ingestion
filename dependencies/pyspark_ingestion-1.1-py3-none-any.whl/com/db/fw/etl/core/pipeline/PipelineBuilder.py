from com.db.fw.etl.core.exception.EtlExceptions import EtlBuilderException
from com.db.fw.etl.core.pipeline.PipelineGraph import PipelineGraph, Pipeline, PipelineNode, PipelineNodeStatus
from com.db.fw.etl.core.samples.SampleTasks import *
from com.db.fw.etl.core.readers.CommonReaders import *
from com.db.fw.etl.core.processors.CommonProcessors import *
from com.db.fw.etl.core.readers.CommonStreamReaders import *
from com.db.fw.etl.core.writers.CommonWriters import DeltaWriter, ConsoleWriter, KafkaStreamWriter


class PipelineBuilder:
    def __init__(self, spark, name, logger, pip_id, io_service):
        self.pipelineGraph = PipelineGraph()
        self.logger = logger
        self.pipeLineName = name
        self.spark = spark
        self.pipid = pip_id
        self.io_service = io_service

    def add_node(self, node):
        self.pipelineGraph.add_node(node)
        return self

    def add_node_after(self, after_node_name, node):
        self.pipelineGraph.add_node(node)
        node_after = self.pipelineGraph.get_node(after_node_name)
        self.pipelineGraph.add_edge(node_after, node)
        return self

    def build(self):
        pipeline = Pipeline(self.logger, self.spark, self.pipelineGraph, self.pipeLineName, self.pipid, self.io_service)
        return pipeline

    def get_json_dump(pipeline):
        nodes = pipeline.pipelineGraph.nodes
        pip_id = pipeline.pipelineid
        name = pipeline.name
        meta_jsons = []

        for n in nodes.values():
            node_metadata = {}

            in_edges_coll = []
            node_metadata["in_edges_coll"] = in_edges_coll
            in_edges = n.in_edges
            for edge in in_edges:
                in_edges_coll.append(edge.reprJSON())

            out_edges_coll = []
            node_metadata["out_edges_coll"] = out_edges_coll
            out_edges = n.out_edges
            for edge in out_edges:
                out_edges_coll.append(edge.reprJSON())

            node_metadata["task"] = n.task.reprJSON()
            node_metadata["node"] = n.reprJSON()

            meta_jsons.append(node_metadata)

        return (pip_id, name, meta_jsons)

    def build_pipeline(pip_id, name, jsons):
        print(jsons)


class PipelineNodeBuilder:

    AUTO_LOADER = "auto_loader"

    SAMPLE_DF_READER = "df_reader"
    SAMPLE_DF_WRITER = "df_writer"
    SAMPLE_DF_PROCESSOR = "df_processor"
    CUSTOM_PROCESSOR = "custom_processor"

    GENERIC_BATCH_READER = "generic_batch_reader"
    EVENT_HUBS_READER = "event_hubs_reader"
    EVENT_HUBS_BATCH_READER = "event_hubs_batch_reader"

    CSV_READER = "csv_batch_reader"
    ORC_READER = "orc_batch_reader"
    AVRO_READER = "avro_batch_reader"
    TEXT_READER = "text_batch_reader"
    JSON_READER = "json_batch_reader"

    KAFKA_READER = "kafka_reader"
    KAFKA_WRITER = "kafka_writer"

    PARQUET_READER = "parquet_batch_reader"
    RDMS_READER = "rdms_batch_reader"
    
    GENERIC_PROCESSOR = "generic_processor"
    SQL_PROCESSOR = "sql_processor"
    RULES_PROCESSOR = "rules_processor"
    DATA_VALIDATAION_PROCESSOR = "data_validation_processor"


    DELTA_READER = "delta_batch_reader"
    DELTA_WRITER = "delta_writer"

    STREAM_CONSOLE_WRITER = "stream_console_writer"

    def __init__(self):
        self.task_id = None
        self.name = None
        self.input_options = {}
        self.out_options = {}
        self.task_output_type = None
        self.type = None

    def set_type(self, task_type):
        self.type = task_type
        return self

    def add_input_option(self, key, value):
        self.input_options[key] = value
        return self

    def add_input_options(self, option_pairs):
        for x in option_pairs:
            self.input_options[x] = option_pairs[x]
        return self

    def add_output_option(self, key, value):
        self.output_options[key] = value
        return self

    def add_output_options(self, option_pairs):
        for x in option_pairs:
            self.output_options[x] = option_pairs[x]
        return self

    def set_task_id(self, id):
        self.task_id = id
        return self
    
    def set_name(self, name):
        self.name = name
        return self

    def get_task(self, task_type):
        tasks = {
                self.AUTO_LOADER: AutoLoader(self.name, self.type),
                self.CSV_READER: CSVBatchReader(self.name, self.type),
                self.ORC_READER: OrcBatchReader(self.name, self.type),
                self.AVRO_READER: AvroBatchReader(self.name, self.type),
                self.TEXT_READER: TextBatchReader(self.name, self.type),
                self.CUSTOM_PROCESSOR: SampleDFProcessor(self.name, self.type),
                self.DELTA_WRITER: DeltaWriter(self.name, self.type),

                self.EVENT_HUBS_BATCH_READER: EvenHubsBatchReader(self.name, self.type),
                self.EVENT_HUBS_READER: EvenHubsReader(self.name, self.type),
                self.GENERIC_BATCH_READER: GenericBatchReader(self.name, self.type),

                self.JSON_READER: JsonBatchReader(self.name, self.type),
                self.KAFKA_READER: KafkaReader(self.name, self.type),

                self.PARQUET_READER: ParquetBatchReader(self.name, self.type),
                self.RDMS_READER: RDBMSBatchReader(self.name, self.type),

                self.GENERIC_PROCESSOR: GenericProcessor(self.name, self.type),
                self.SQL_PROCESSOR: SQLProcessor(self.name, self.type),
                self.DATA_VALIDATAION_PROCESSOR: DataValidationProcessor(self.name, self.type),
                self.RULES_PROCESSOR: RulesProcessor(self.name, self.type),

                self.SAMPLE_DF_READER: SampleDFReader(self.name, self.type), 
                self.SAMPLE_DF_WRITER: SampleDFWriter(self.name, self.type),
                self.SAMPLE_DF_PROCESSOR: SampleDFProcessor(self.name, self.type),
                
                self.STREAM_CONSOLE_WRITER: ConsoleWriter(self.name, self.type),
                self.KAFKA_WRITER: KafkaStreamWriter(self.name, self.type)
                }
        return tasks.get(task_type, EtlBuilderException(f" Invalid Param {self.type}") )

    def build(self):
        if self.name is None or self.type is None:
            raise EtlBuilderException(" Insufficient Param while building the node Name and Type are mandatory")

        task = self.get_task(self.type)
        
        task.add_option_values(self.input_options)
        task.task_status = PipelineNodeStatus.NONE

        node = PipelineNode(self.name, self.task_id, task)
        return node

    def build_custom_node(task_obj):
        task_obj.task_status = PipelineNodeStatus.NONE
        return PipelineNode(task_obj.task_name, task_obj)
