from pyspark.sql.functions import lit

from com.db.fw.etl.core.common.Task import Task
from com.db.fw.etl.core.readers.CommonReaders import BaseReader
from com.db.fw.etl.core.writers.CommonWriters import BaseWriter
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS

class SampleDFReader(BaseReader):
    def __init__(self, name, task_type):
        BaseReader.__init__(self, name, task_type)

    def execute(self):
        df = self.spark.range(20)
        self.set_output_dataframe(df)
        print("Executing... {}".format(self.task_name))

        count_stats = df.count()
        self.add_facts("input_row_count", count_stats)


class SampleDFWriter(BaseWriter):
    def __init__(self, name, task_type):
        BaseWriter.__init__(self, name, task_type)

    def execute(self):
        df = self.get_input_dataframe()
        df.write.format("delta") \
            .mode("overwrite") \
            .option("overwriteSchema", "true") \
            .saveAsTable(f"{COMMON_CONSTANTS.METADATA_DB}.dummy_table1")

        print("Executing... {}".format(self.task_name))


class SampleDFProcessor(Task):
    def __init__(self, name, task_type):
        Task.__init__(self, name, task_type)

    def execute(self):
        print("In Sample Processor : Task Name {}".format(self.task_name))
        df = self.get_input_dataframe()

        df = df.withColumn("dummy_col", lit(0.3))

        self.set_output_dataframe(df)
        print("Executing... {}".format(self.task_name))

        # fact calc
        count_stats = df.count()
        self.add_facts("process_row_count", count_stats)
