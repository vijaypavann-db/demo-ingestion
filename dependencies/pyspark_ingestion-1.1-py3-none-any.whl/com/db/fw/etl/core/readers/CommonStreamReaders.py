import json
import logging

from datetime import datetime, timedelta

from com.db.fw.etl.core.exception.EtlExceptions import InsufficientParamsException
from com.db.fw.etl.core.common.Task import Task
from com.db.fw.etl.core.readers.CommonReaders import BaseReader
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS

logger = logging.getLogger()

class EvenHubsReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        import datetime as dt
        ehConf = {}

        start_time = self.input_options.get("startingPosition", None)
        end_time = self.input_options.get("endingPosition", None)
        start_before = self.input_options.get("start_before_current_time_in_minutes", None)
        connectionString = str(self.input_options.get("connectionString", None))

        if connectionString is None:
            raise InsufficientParamsException(self.task_name, self.pipeline_name, self.input_options,
                                              "connectionString param is missing.. ")
        ehConf['eventhubs.connectionString'] = connectionString

        if start_time is not None:
            startingEventPosition = {
                "offset": start_time,
                "seqNo": -1,  # not in use
                "enqueuedTime": None,  # not in use
                "isInclusive": True
            }
            ehConf["eventhubs.startingPosition"] = json.dumps(startingEventPosition)

        if end_time is not None and start_time is not None:

            endingEventPosition = {
                "offset": None,  # not in use
                "seqNo": -1,  # not in use
                "enqueuedTime": end_time,
                "isInclusive": True
            }
            ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)
        elif start_time is not None:
            end_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            endingEventPosition = {
                "offset": None,  # not in use
                "seqNo": -1,  # not in use
                "enqueuedTime": end_time,
                "isInclusive": True
            }
            ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)

        if start_before is not None:
            d = datetime.now() - timedelta(hours=0, minutes=start_before)
            start_time = d.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

            endTime = dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

            # Create the positions
            startingEventPosition = {
                "offset": None,
                "seqNo": -1,  # not in use
                "enqueuedTime": start_time,  # not in use
                "isInclusive": True
            }
            ehConf["eventhubs.startingPosition"] = json.dumps(startingEventPosition)

            endingEventPosition = {
                "offset": None,  # not in use
                "seqNo": -1,  # not in use
                "enqueuedTime": endTime,
                "isInclusive": True
            }

            ehConf["maxEventsPerTrigger"] = 10000
            ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)

        print("**** Configuration **** {}".format(str(ehConf)))

        df = self.spark \
            .readStream \
            .format("eventhubs") \
            .options(**ehConf) \
            .load()
        self.set_output_dataframe(df)


class JsonReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        pass
        # df = self.spark
        #     .readStream\
        #
        #     .schema()
        #     .json()
        #
        # self.set_output_dataframe(df)


class DeltaStreamReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        pass


class KafkaReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        try:
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)
            reader_configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            print("Executing... {}".format(self.task_name))

            kafka_df = (self.spark 
                            .readStream 
                            .format("kafka") 
                            .options(**reader_options) 
                            .load())

            self.set_output_dataframe(kafka_df)


            count_stats = kafka_df.count()
            self.add_facts("input_row_count", count_stats)

        except Exception as e:
            logger.error(e)



class AutoLoader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
        reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

        file_format = configs.get("file_format")
        input_path = configs.get("input_path")

        try:
          df_reader = self.spark.readStream.format("cloudFiles").option("cloudFiles.format", file_format)
          schema_location = configs.get("schema_location")
          if schema_location is not None:
              #if schema is not assigned, schema inference will occur
              df_reader = df_reader.option("cloudFiles.schemaLocation",schema_location)
          else:
              schema = configs.get("schema")
              df_reader = df_reader.schema(schema)

          if reader_options is not None:
              df_reader = df_reader.options(**reader_options)
          
          df = df_reader.load(input_path)
          print("Autoloader Reader Class is executing")
          self.set_output_dataframe(df)
          print("Executing... {}".format(self.task_name))
          
        except Exception as e:
          logger.error(e)
    




