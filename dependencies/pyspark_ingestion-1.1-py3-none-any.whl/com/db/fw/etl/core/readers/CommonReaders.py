import json
from datetime import datetime, timedelta
import traceback
from com.db.fw.etl.core.common.Commons import Commons
from com.db.fw.etl.core.configs.Configs import CONFIGS
from com.db.fw.etl.core.exception.EtlExceptions import InsufficientParamsException
from com.db.fw.etl.core.common.Task import Task
from com.db.fw.etl.core.common.Constants import COMMON_CONSTANTS

class BaseReader(Task):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

class GenericBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        try:
            print("Executing... {}".format(self.task_name))

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

            file_format = configs.get(COMMON_CONSTANTS.FORMAT)
            input_path = configs.get(COMMON_CONSTANTS.PATH)

            df_reader = self.spark.read.format(file_format)
            if reader_options is not None:
                df_reader = df_reader.options(**reader_options)
            df = df_reader.load(input_path)
            
            self.set_output_dataframe(df)
            
            count_stats = df.count()
            self.add_facts("input_row_count", count_stats)
        except Exception as e:
            Commons.printErrorMessage("Exception occurred in GenericBatchReader {} ".format(str(e)))

class EvenHubsBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        import datetime as dt
        ehConf = {}

        start_time = self.input_options.get("startingPosition", None)
        end_time = self.input_options.get("endingPosition", None)
        start_before = self.input_options.get("start_before_current_time_in_minutes", None)
        connectionString = str(self.input_options.get("connectionString", None))

        if connectionString is None:
            raise InsufficientParamsException(self.task_name, self.pipeline_name, self.input_options,
                                              "connectionString param is missing.. ")
        ehConf['eventhubs.connectionString'] = connectionString

        if start_time is not None:
            startingEventPosition = {
                "offset": start_time,
                "seqNo": -1,  # not in use
                "enqueuedTime": None,  # not in use
                "isInclusive": True
            }
            ehConf["eventhubs.startingPosition"] = json.dumps(startingEventPosition)

        if end_time is not None and start_time is not None:

            endingEventPosition = {
                "offset": None,  # not in use
                "seqNo": -1,  # not in use
                "enqueuedTime": end_time,
                "isInclusive": True
            }
            ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)
        elif start_time is not None:
            end_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            endingEventPosition = {
                "offset": None,  # not in use
                "seqNo": -1,  # not in use
                "enqueuedTime": end_time,
                "isInclusive": True
            }
            ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)

        if start_before is not None:
            d = datetime.now() - timedelta(hours=0, minutes=start_before)
            start_time = d.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

            endTime = dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

            # Create the positions
            startingEventPosition = {
                "offset": None,
                "seqNo": -1,  # not in use
                "enqueuedTime": start_time,  # not in use
                "isInclusive": True
            }
            ehConf["eventhubs.startingPosition"] = json.dumps(startingEventPosition)

            endingEventPosition = {
                "offset": None,  # not in use
                "seqNo": -1,  # not in use
                "enqueuedTime": endTime,
                "isInclusive": True
            }
            ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)

        print("**** Configuration **** {}".format(str(ehConf)))

        df = self.spark \
            .read \
            .format("eventhubs") \
            .options(**ehConf) \
            .load()

        self.set_output_dataframe(df)


class EvenHubsBatchReaderNB(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        import datetime as dt
        ehConf = {}

        # Start from beginning of stream
        startOffset = "-1"

        d = datetime.now() - timedelta(hours=2, minutes=0)
        start_time = d.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        # End at the current time. This datetime formatting creates the correct string format from a python datetime
        # object

        endTime = dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

        # Create the positions
        startingEventPosition = {
            "offset": None,
            "seqNo": -1,  # not in use
            "enqueuedTime": start_time,  # not in use
            "isInclusive": True
        }

        endingEventPosition = {
            "offset": None,  # not in use
            "seqNo": -1,  # not in use
            "enqueuedTime": endTime,
            "isInclusive": True
        }

        connectionString = ""

        ehConf['eventhubs.connectionString'] = connectionString
        ehConf["eventhubs.startingPosition"] = json.dumps(startingEventPosition)
        ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)
        ehConf["eventhubs.maxEventsPerTrigger"] = 2 * 5

        df = self.spark \
            .read \
            .format("eventhubs") \
            .options(**ehConf) \
            .load()

        df = df.repartition(200)

        self.set_output_dataframe(df)


class CSVBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    # TODO read schema from headerPath / headerCols & add the datatype info
    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.CSVBatchReader ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

            file_format = configs.get(COMMON_CONSTANTS.FORMAT)
            input_path = configs.get(COMMON_CONSTANTS.PATH)

            file_format_options = CONFIGS.CSV_READER_OPTIONS
            csv_options_default = CONFIGS.CSV_READER_OPTIONS_DEFAULT

            Commons.optionsValidations(reader_options,file_format_options)

            df_reader = self.spark.read.format(file_format)
            df_reader = df_reader.options(**csv_options_default)
            if reader_options is not None:
                df_reader = df_reader.options(**reader_options)
            df = df_reader.load(input_path)
            
            self.set_output_dataframe(df)
            df.createOrReplaceTempView(self.task_name)
            
            count_stats = df.count()
            self.add_facts("input_row_count", count_stats)
            
        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in CSVBatchReader {} ".format(str(e)))


class ParquetBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        try:
            execMsg = f"*** Executing {__name__}.ParquetBatchReader ... {self.task_name}"
            Commons.printFlowMessage(execMsg)

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

            file_format = configs.get(COMMON_CONSTANTS.FORMAT)
            input_path = configs.get(COMMON_CONSTANTS.PATH)

            file_format_options = CONFIGS.PARQUET_READER_OPTIONS

            Commons.optionsValidations(reader_options,file_format_options)

            df_reader = self.spark.read.format(file_format)
            if reader_options is not None:
                df_reader = df_reader.options(**reader_options)
            df = df_reader.load(input_path)
            
            self.set_output_dataframe(df)
            df.createOrReplaceTempView(self.task_name)
            
            count_stats = df.count()
            self.add_facts("input_row_count", count_stats)

        except Exception as e:
            Commons.printErrorMessage("---> Exception occurred in ParquetBatchReader {} ".format(str(e)))

class OrcBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        try:
            print("Executing ... {}".format(self.task_name))

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

            file_format = configs.get(COMMON_CONSTANTS.FORMAT)
            input_path = configs.get(COMMON_CONSTANTS.PATH)

            file_format_options=CONFIGS.ORC_READER_OPTIONS

            Commons.optionsValidations(reader_options,file_format_options)

            df_reader = self.spark.read.format(file_format)
            if reader_options is not None:
                df_reader = df_reader.options(**reader_options)
            df = df_reader.load(input_path)
            
            self.set_output_dataframe(df)
            
            count_stats = df.count()
            self.add_facts("input_row_count", count_stats)
        except Exception as e:
            Commons.printErrorMessage("Exception occurred in CSVBatchReader {} ".format(str(e)))

class AvroBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        try:
            print("Executing ... {}".format(self.task_name))

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

            file_format = configs.get(COMMON_CONSTANTS.FORMAT)
            input_path = configs.get(COMMON_CONSTANTS.PATH)

            file_format_options=CONFIGS.AVRO_READER_OPTIONS

            Commons.optionsValidations(reader_options,file_format_options)

            df_reader = self.spark.read.format(file_format)
            if reader_options is not None:
                df_reader = df_reader.options(**reader_options)
            df = df_reader.load(input_path)
            
            self.set_output_dataframe(df)
            
            count_stats = df.count()
            self.add_facts("input_row_count", count_stats)
        except Exception as e:
            Commons.printErrorMessage("Exception occurred in AVROBatchReader {} ".format(str(e)))   

class TextBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        try:
            print("Executing ... {}".format(self.task_name))

            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

            file_format = configs.get(COMMON_CONSTANTS.FORMAT)
            input_path = configs.get(COMMON_CONSTANTS.PATH)

            file_format_options=CONFIGS.TEXT_READER_OPTIONS

            Commons.optionsValidations(reader_options,file_format_options)

            df_reader = self.spark.read.format(file_format)
            if reader_options is not None:
                df_reader = df_reader.options(**reader_options)
            df = df_reader.load(input_path)
            
            self.set_output_dataframe(df)
            
            count_stats = df.count()
            self.add_facts("input_row_count", count_stats)
        except Exception as e:
            Commons.printErrorMessage("Exception occurred in TextBatchReader {} ".format(str(e)))   


class JsonBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        try:
            print("Executing ... {}".format(self.task_name))
            
            configs = self.input_options.get(COMMON_CONSTANTS.CONFIGS)
            reader_options = self.input_options.get(COMMON_CONSTANTS.OPTIONS)

            file_format = configs.get(COMMON_CONSTANTS.FORMAT)
            input_path = configs.get(COMMON_CONSTANTS.PATH)

            file_format_options=CONFIGS.JSON_READER_OPTIONS
            json_options_default=CONFIGS.JSON_READER_OPTIONS_DEFAULT

            Commons.optionsValidations(reader_options,file_format_options)

            df_reader = self.spark.read.format(file_format)
            df_reader=df_reader.option(**json_options_default)
            if reader_options is not None:
                df_reader = df_reader.options(**reader_options)
            df = df_reader.load(input_path)
            
            self.set_output_dataframe(df)

            count_stats = df.count()
            self.add_facts("input_row_count", count_stats)
        except Exception as e:
            Commons.printErrorMessage("Exception occurred in JsonBatchReader {} ".format(str(e)))
        


class RDBMSBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        pass


class DeltaBatchReader(BaseReader):
    def __init__(self, task_name, task_type):
        Task.__init__(self, task_name, task_type)

    def execute(self):
        pass
